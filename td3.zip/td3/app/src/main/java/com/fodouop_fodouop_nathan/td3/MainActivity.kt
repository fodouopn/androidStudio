package com.fodouop_fodouop_nathan.td3

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    // Déclaration des attributs pour la batterie
    private var batteryLevel: Int = 0
    private var batteryMaxLevel: Int = 100
    private lateinit var batteryReceiver: BroadcastReceiver

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        // Initialisation et enregistrement du BroadcastReceiver
        initBatteryReceiver()
        registerBatteryReceiver()
    }

    // Initialisation du BatteryReceiver
    private fun initBatteryReceiver() {
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                // Récupération des informations sur la batterie
                val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) // Niveau actuel
                val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1) // Niveau maximal

                // Mise à jour des niveaux de batterie
                if (level != -1 && scale != -1) {
                    batteryLevel = level
                    batteryMaxLevel = scale

                    // Appel de la méthode pour afficher le niveau de batterie
                    displayBatteryLevel()
                }
            }
        }
    }

    // Méthode pour afficher le niveau de batterie
    private fun displayBatteryLevel() {
        Toast.makeText(
            this@MainActivity,
            "Niveau de batterie : $batteryLevel / $batteryMaxLevel",
            Toast.LENGTH_SHORT
        ).show()
    }

    // Enregistrement du BroadcastReceiver pour écouter les changements de batterie
    private fun registerBatteryReceiver() {
        // Enregistrement du BatteryReceiver avec l'IntentFilter pour les changements de batterie

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }


}