package com.fodouop_fodouop_nathan.td1

import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
    public fun tryToConnect(view: View)
    {
        // Récupérer le champ texte de l'email
        val emailField = findViewById<EditText>(R.id.editTextTextEmailAddress)
        // Récupérer la valeur de l'email
        val email = emailField.text.toString()

        // Récupérer le champ texte du mot de passe
        val passwordField = findViewById<EditText>(R.id.editTextTextPassword)
        // Récupérer la valeur du mot de passe
        val password = passwordField.text.toString()
        AlertDialog
            .Builder(this)
            .setTitle("Demande de connexion")
            .setMessage("Nouvelle demande de connexion")
            .setMessage("Email : $email\n Password: $password")
            .show()

    }
}