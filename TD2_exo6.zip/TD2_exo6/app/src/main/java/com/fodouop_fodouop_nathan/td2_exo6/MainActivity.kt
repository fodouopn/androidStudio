package com.fodouop_fodouop_nathan.td2_exo6

import Contact
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.ArrayList

class MainActivity : AppCompatActivity() {
    private var dataPerson: ArrayList<Contact> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Charger le layout
        setContentView(R.layout.activity_main)

        // Initialiser les contacts
        initContacts()

        // Initialiser la ListView
        initContactsListView()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main))
        { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }

    }

    private fun initContacts(){
        dataPerson.add(Contact("Meunier","Charles","0606060606",R.drawable.meunier))
        dataPerson.add(Contact("Serier","Karine","0707070707",R.drawable.serier))
        dataPerson.add(Contact("Heyrman","Barthélémy","0808080808",R.drawable.heyrman))


    }

    private  fun initContactsListView()
    {
        val listView = findViewById<ListView>(R.id.lstContacts)
        listView.adapter = ContactAdapter(this, dataPerson)


        // Ajout de l'événement OnItemClickListener pour appeler un contact
        listView.setOnItemClickListener { _, _, position, _ ->
            // Récupérer le contact cliqué
            val contact = dataPerson[position]

            // Créer un Intent pour ouvrir l'application de numérotation
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                // Passer le numéro de téléphone dans l'intention
                data = Uri.parse("tel:${contact.phoneNumber}")
            }

            // Démarrer l'intent pour ouvrir l'application de numérotation
            startActivity(dialIntent)
        }
    }


}

