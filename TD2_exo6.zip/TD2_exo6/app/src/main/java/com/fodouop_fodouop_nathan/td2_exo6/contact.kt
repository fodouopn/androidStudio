
data class Contact(
    val lastname: String,
    val firstname: String,
    val phoneNumber: String,
    val photo: Int
)