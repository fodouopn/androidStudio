package com.fodouop_fodouop_nathan.td2_exo6

import Contact
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class ContactAdapter (
    private val context: Context,
    private val dataSource: ArrayList<Contact>
) : BaseAdapter()
{
    private val inflater: LayoutInflater =
        context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override  fun getItem(position: Int): Contact {
        return dataSource[position]
    }

    override  fun getCount(): Int {
        return dataSource.size
    }

    override fun getView(position: Int, convertView :View?, parent: ViewGroup?): View {
        val  rowView = inflater.inflate(R.layout.contacts_list_item, parent, false)

        // Récupérer les vues TextView à partir de la mise en page
        val LastNameTextView = rowView.findViewById<TextView>(R.id.lblLastName)
        val FirstNameTextView = rowView.findViewById<TextView>(R.id.lblFirstName)
        val phoneTextView = rowView.findViewById<TextView>(R.id.lblPhoneNumber)
        val photo = rowView.findViewById<ImageView>(R.id.imageView)

        // Obtenir le contact à la position actuelle
        val contact = getItem(position) as Contact

        // Mettre à jour le contenu des TextViews
        LastNameTextView.text = contact.lastname
        FirstNameTextView.text = contact.firstname
        phoneTextView.text = contact.phoneNumber
        photo.setImageResource(contact.photo)

        return rowView
    }
}