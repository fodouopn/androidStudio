package com.example.androidtp2

data class OrderData(
    val recipeId: Int,
    val doughId: Int
)
