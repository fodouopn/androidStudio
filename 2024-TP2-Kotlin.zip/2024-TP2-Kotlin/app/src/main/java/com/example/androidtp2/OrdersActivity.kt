package com.example.androidtp2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class OrdersActivity : AppCompatActivity() {
    // variables orders
    private var orders: ArrayList<Order> = ArrayList()
    private lateinit var adapter: OrderAdapter
    private var token: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_orders)

        Log.d("OrdersActivity", "Activity Started")

// Récupération du token depuis l'intent
        token = intent.getStringExtra("TOKEN")
        if (token == null) {
            Toast.makeText(this, "Token du login  manquant", Toast.LENGTH_SHORT).show()
            finish()  // Fermer l'activité si le token est absent
            return
        }
        Log.d("OrdersActivity", "Token récupéré : $token")


        // Initialisation de l'adaptateur
        adapter = OrderAdapter(this, orders)

        val ordersListView = findViewById<ListView>(R.id.lstOrders)
        ordersListView.adapter = adapter


    }

    override fun onResume() {
        super.onResume()
        loadOrders() //
    }

    public fun newOrder(view: View) {

        val intent = Intent(this, OrderActivity::class.java)
        intent.putExtra("auth_commande", token)
        startActivity(intent)
    }


    // Dans la fonction displayOrders, vérifiez également la réponse
    private fun displayOrders(responseCode: Int, loadedOrders: List<Order>?) {

        if (responseCode == 200 && loadedOrders != null) {
             orders.clear()
            orders.addAll(loadedOrders) // Ajout des commandes récupérées
            runOnUiThread {
                adapter.notifyDataSetChanged()
            }
        } else if (responseCode == 401) {
            Toast.makeText(this, "Accès non autorisé", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Erreur lors du chargement des commandes", Toast.LENGTH_SHORT).show()
            Log.d("OrdersActivity", "Erreur lors du chargement des commandes, loadedOrders: $loadedOrders")
        }
    }

    private fun loadOrders() {
        // Vérification si le token est valide
        if (token.isNullOrEmpty()) {
            Toast.makeText(this, "Token manquant, veuillez vous reconnecter", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        Api().get("https://mypizza.lesmoulinsdudev.com/orders", ::displayOrders,token)
    }
}


