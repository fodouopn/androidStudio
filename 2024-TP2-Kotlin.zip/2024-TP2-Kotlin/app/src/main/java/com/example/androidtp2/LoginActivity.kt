package com.example.androidtp2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val loginButton: Button = findViewById(R.id.btnConect)
        loginButton.setOnClickListener {
            login()  // Appel de la méthode `login` lorsqu’on clique sur le bouton connexion
        }
    }

    public fun registerNewAccount(view: View)
    {
        val intent = Intent(this, RegisterActivity::class.java);
        startActivity(intent);
    }

    private fun login() {
        val mail = findViewById<EditText>(R.id.txtMail).text.toString()
        val password = findViewById<EditText>(R.id.txtPassword).text.toString()
        val loginData = LoginData(mail, password)
        Api().post("https://mypizza.lesmoulinsdudev.com/auth", loginData, ::loginSuccess)
    }


    // sauvergarder le token pour une utilisation ulterieure

//    private fun saveToken(token: String) {
//        val sharedPreferences = getSharedPreferences("app_prefs", MODE_PRIVATE)
//        with(sharedPreferences.edit()) {
//            putString("auth_token", token)
//            apply()
//        }
//    }


    private fun loginSuccess(responseCode: Int,token: String?)
    {

        if (responseCode == 200  && token != null) {
//            // Enregistrer le token pour un usage futur
//            saveToken(token)

            val intent = Intent(this, OrdersActivity::class.java)
            intent.putExtra("TOKEN", token)
            startActivity(intent)
        } else {
            Toast.makeText(this, "Erreur de connexion", Toast.LENGTH_SHORT).show()
        }
    }



}