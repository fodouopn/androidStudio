package com.example.androidtp2

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class OrderAdapter (private val context: Context, private val dataSource: ArrayList<Order>) :
    BaseAdapter() {
    private val inflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int = dataSource.size

    override fun getItem(position: Int): Any = dataSource[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        // Réutiliser la vue existante ou en créer une nouvelle si nécessaire
        val rowView = convertView ?: inflater.inflate(R.layout.order_list_item, parent, false)

        // Obtention de l'objet Order correspondant à la position
        val order = getItem(position) as Order

        // Récupérer les TextView de la vue `order_list_item`
        val recipeTextView = rowView.findViewById<TextView>(R.id.txtrecipe)
        val doughTextView = rowView.findViewById<TextView>(R.id.txtdough)
        val dateTextView = rowView.findViewById<TextView>(R.id.txtdate)
        val timeTextView = rowView.findViewById<TextView>(R.id.txttime)

        // Remplir les TextView avec les données de l'objet `Order`
        recipeTextView.text = order.recipe
        doughTextView.text = order.dough
        dateTextView.text = order.date
        timeTextView.text = order.time

        return  rowView
    }

}