package com.example.androidtp2

data class Order(
    val recipe: String,
    val dough: String,
    val orderDate: String
){
    // Extraction de la date et de l'heure
    val date: String
        get() = orderDate.split(" ")[0]

    val time: String
        get() = orderDate.split(" ")[1]
}
