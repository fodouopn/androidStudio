package com.example.androidtp2

data class DoughData(
    val id: Int,
    val name: String  //epaisseur de la pate
)
{
    override fun toString(): String {
        return name
    }
}