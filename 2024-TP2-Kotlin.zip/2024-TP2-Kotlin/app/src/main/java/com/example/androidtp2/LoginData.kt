package com.example.androidtp2

data class LoginData(
    val mail: String,
    val password: String
)
