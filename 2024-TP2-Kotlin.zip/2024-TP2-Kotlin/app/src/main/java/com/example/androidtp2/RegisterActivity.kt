package com.example.androidtp2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import org.w3c.dom.Text

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val registerButton: Button = findViewById(R.id.btnRegister)
        registerButton.setOnClickListener {
            register()  // Appel de la méthode `register` lorsqu’on clique sur le bouton
        }
    }

    public fun goToLogin(view: View)
    {
        finish();
    }

    private fun register() {
        val name =  findViewById<EditText>(R.id.txtRegisterName).text.toString()
        val mail = findViewById<EditText>(R.id.txtRegisterMail).text.toString()
        val password = findViewById<EditText>(R.id.txtRegisterPassword).text.toString()

        // Vérification rapide des champs
        if (name.isEmpty() || mail.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show()
            return
        }else{
            // Indication de l'envoi de la requête
            Toast.makeText(this, "Enregistrement en cours...", Toast.LENGTH_SHORT).show()

        }

        val registerData = RegisterData(name, mail, password)


        Api().post("https://mypizza.lesmoulinsdudev.com/register", registerData, ::registerSuccess)
    }

    private fun registerSuccess(responseCode: Int) {
        if (responseCode == 200) {
            runOnUiThread {
                Toast.makeText(
                    this,
                    "Inscription réussie! Retour à la connexion.",
                    Toast.LENGTH_SHORT
                ).show()
            }
            finish()
        } else {
            Toast.makeText(this, "Erreur lors de l’enregistrement", Toast.LENGTH_SHORT).show()
        }
    }


}