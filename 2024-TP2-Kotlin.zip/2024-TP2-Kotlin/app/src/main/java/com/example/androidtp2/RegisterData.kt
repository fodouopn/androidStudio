package com.example.androidtp2

data class RegisterData(
    val name : String,
    val  mail: String,
    val password: String
)
