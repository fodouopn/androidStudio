package com.example.androidtp2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class OrderActivity : AppCompatActivity() {

    //recipes variables
    private var recipes: ArrayList<RecipeData> = ArrayList()
    private lateinit var recipesAdapter: ArrayAdapter<RecipeData>

    // dough variables
    private var doughs: ArrayList<DoughData> = ArrayList()
    private lateinit var doughsAdapter: ArrayAdapter<DoughData>

    private var token: String? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order)

        //on initialise recipesAdapter
        recipesAdapter = ArrayAdapter<RecipeData>(this,androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, recipes)

        //on initialise doughsAdapter
        doughsAdapter = ArrayAdapter<DoughData>(this,androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, doughs)

        // Récupère le token transmis depuis OrdersActivity
        token = intent.getStringExtra("auth_commande")

        // Vérifie si le token est présent et valide
        if (token == null) {
            Toast.makeText(this, "Token de commande manquant ", Toast.LENGTH_SHORT).show()
            finish() // Ferme l'activité si le token est absent
            return
        }


        loadRecipes()   // Appel de la méthode loadRecipes pour charger les recettes au démarrage
        loadDougs()
        initializeSpinners()

        //connecter le bouton commander a la methode sendOrder
        val sendBoutton : Button = findViewById(R.id.btnOrder)
        sendBoutton.setOnClickListener {
            sendOrder()
        }
    }

    public fun goToOrders(view: View)
    {
        finish();
    }

    private fun loadRecipesSuccess(responseCode: Int,loadedRecipes: List<RecipeData>?)
    {
        if(responseCode == 200 && loadedRecipes != null){
            recipes.clear() // on vide l'attribut recipes
            recipes.addAll(loadedRecipes) // on ajoute dans recipes les elements de loadedRecipes
            updateRecipesList()
        }
    }

    private fun loadDoughsSuccess(responseCode: Int,loadedDoughs: List<DoughData>?)
    {
        if(responseCode == 200 && loadedDoughs != null){
            doughs.clear() // on vide l'attribut dough
            doughs.addAll(loadedDoughs) // on ajoute dans recipes les elements de loadedDoughs
            updateDoughsList()
        }
    }

    private fun loadRecipes()
    {
        Api().get("https://mypizza.lesmoulinsdudev.com/recipes",::loadRecipesSuccess)
    }

    private fun loadDougs()
    {
        Api().get("https://mypizza.lesmoulinsdudev.com/doughs",::loadDoughsSuccess)
    }


    private fun initializeSpinners()
    {

        // Liaison de recipesAdapter à un Spinner
         val spinRecipe =  findViewById<Spinner>(R.id.spinRecipe) // on recupere l'element de la liste déroulante

        //Liaison de doughsAdapter a un spinner
         val spinDough = findViewById<Spinner>(R.id.spinDough)
        spinRecipe.adapter = recipesAdapter
        spinDough.adapter = doughsAdapter
    }

    private fun updateRecipesList()
    {
        runOnUiThread {
            recipesAdapter.notifyDataSetChanged()
        }
    }

    private fun updateDoughsList()
    {
        runOnUiThread {
            doughsAdapter.notifyDataSetChanged()
        }
    }

    private fun orderSuccess(responseCode: Int)
    {
        if (responseCode == 200)
        {
            runOnUiThread {
                Toast.makeText(
                    this,
                    "Commande envoyée ! Retour a la liste des commandes",
                    Toast.LENGTH_SHORT
                ).show()
            }
//                // Créer un Intent pour retourner à OrdersActivity
//                val ordersIntent = Intent(this, OrdersActivity::class.java)
//                ordersIntent.putExtra("TOKEN", token) // Transmettre le token à OrdersActivity
//                startActivity(ordersIntent) // Démarre OrdersActivity
            finish()



        } else {
            Toast.makeText(this, "Erreur lors de la commande", Toast.LENGTH_SHORT).show()
        }
    }


    // methode pour recuperer les id de la recette et de l'epaisseur de la pate
    private fun sendOrder()
    {
        // Liaison de recipesAdapter à un Spinner
         val spinRecipe =  findViewById<Spinner>(R.id.spinRecipe) // on recupere l'element de la liste déroulante
        //Liaison de doughsAdapter a un spinner
         val spinDough = findViewById<Spinner>(R.id.spinDough)


        val recipeId = (spinRecipe.selectedItem as RecipeData).id
        val doughId = (spinDough.selectedItem as DoughData).id
        val orderData = OrderData(recipeId, doughId)

        // Debug : afficher le token dans le logcat
        Log.d("OrderActivity", "Token: $token")

        //Toast.makeText(this, "Commande en cours d'envoie...", Toast.LENGTH_SHORT).show()

        Api().post("https://mypizza.lesmoulinsdudev.com/order", orderData, ::orderSuccess, token)
    }


}