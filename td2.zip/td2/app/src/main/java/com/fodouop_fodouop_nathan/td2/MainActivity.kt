package com.fodouop_fodouop_nathan.td2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.SeekBar.OnSeekBarChangeListener
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    private var nameBooking: String=""
    private var bookingDate: String = ""
    private var stayDuration: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        initNameReservation()
        initCalendarEvent()
        initSeekBarEvent()
        buttonEvent()

    }
private fun buttonEvent()
{
    val connectButton = findViewById<Button>(R.id.btnConnection)
    connectButton.setOnClickListener{_ ->
        connect()
    }
}
    private fun connect()
    {
        // Récupère la valeur du champ EditText avant d'envoyer les données
        nameBooking = findViewById<EditText>(R.id.nametext).text.toString()

        //Creation de intent
        val intent = Intent(this,MainActivity2::class.java);

        //transmission des informations
        intent.putExtra("bookingDate","$bookingDate");
        intent.putExtra("reservationName","$nameBooking");
        intent.putExtra("time","$stayDuration");

        //Demarrage de la nouvelle activité
        startActivity(intent);
    }

    private fun initNameReservation()
    {
        nameBooking = findViewById<EditText>(R.id.nametext).text.toString()

    }

    private fun initCalendarEvent()
    {
        val calendar = findViewById<CalendarView>(R.id.calendarView)

        calendar.setOnDateChangeListener(object: CalendarView.OnDateChangeListener{
            override  fun onSelectedDayChange(view: CalendarView, year: Int, month: Int, dayOfMonth: Int)
            {
                bookingDate = "$dayOfMonth/$month/$year"
                // Afficher la date dans un AlertDialog
                AlertDialog
                    .Builder(this@MainActivity)
                    .setTitle("Date sélectionnée")
                    .setMessage("La date de réservation est : $bookingDate")
                    .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                    ///.show()

                //alertDialog.show()

                // Mise à jour du label avec la date sélectionnée
                updateBookingDateLabel(bookingDate)
            }
        }

        )

    }
    // Méthode pour mettre à jour le label "Date d'arrivée"
    private fun updateBookingDateLabel(date: String) {
        val bookingDateTextView = findViewById<TextView>(R.id.bookingDateTextView)
        bookingDateTextView.text = "Date d'arrivée : $date"
    }

    private fun initSeekBarEvent()
    {
        val seekbar = findViewById<SeekBar>(R.id.seekBar2)

        seekbar.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener
        {
            override fun onProgressChanged(p0: SeekBar?, progress: Int, p2: Boolean) {
                // Mettre à jour la variable stayDuration avec la progression actuelle
                stayDuration = progress

                // Mettre à jour le label avec la durée
                updateStayDurationLabel(stayDuration)
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }

        })

    }
    // Méthode pour afficher la durée au  label "Durée du sejour"
    private fun updateStayDurationLabel(duree : Int) {
        val dureeTextView = findViewById<TextView>(R.id.DureeTextView)
        dureeTextView.text = "Durée du séjour : $duree jours "
    }


}