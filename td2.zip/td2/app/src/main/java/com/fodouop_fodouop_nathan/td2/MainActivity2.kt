package com.fodouop_fodouop_nathan.td2

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    private var name: String = ""
    private var booking: String = ""
    private var time: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        extractBookingDataFromIntent()
    }

    private fun extractBookingDataFromIntent(){
        // Récupérer l'information transmise avec une valeur par défaut
        val booking = intent.getStringExtra("bookingDate") ?: "Date non définie"
        val name = intent.getStringExtra("reservationName")
        val time = intent.getStringExtra("time")

        val DataTextView = findViewById<TextView>(R.id.dataTextView)
        DataTextView.text = "Nom de la reservation: $name \n Date de réservation : $booking \nna Durée: $time jours"
    }
}